import java.util.*;
import bc.*;

public class RocketLaunch 
{
	int land_round;
	MapLocation loc;
	public RocketLaunch(int land_round, MapLocation loc) 
	{
		this.land_round = land_round;
		this.loc = loc;
	}
}
